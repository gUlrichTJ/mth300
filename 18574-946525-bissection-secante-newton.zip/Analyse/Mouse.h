#include<dos.h>
#include<stddef.h>

  typedef enum Boolean {false,true}  boolean;
  union REGS reg;

        int     etat();
	int     X();
	int     Y();
	void    MouseInit();
	void    MouseOn();
	void    MouseOff();
	int  Left();
	int  Right();
	int MouseIn();

  void MouseInit()
       {
	reg.x.ax=0x00;
	int86(0x33,&reg,&reg);
       }


  void MouseOn()
       {
	reg.x.ax=0x01;
	int86(0x33,&reg,&reg);
       }

  void MouseOff()
       {
	reg.x.ax=0x02;
	int86(0x33,&reg,&reg);
       }

  int  X()
       {
	reg.x.ax=0x03;
	int86(0x33,&reg,&reg);
	return(reg.x.cx);
       }

  int  Y()
       {
	reg.x.ax=0x03;
	int86(0x33,&reg,&reg);
	return(reg.x.dx);
       }

 int  Left()
	  {
	   reg.x.ax=0x03;
	   int86(0x33,&reg,&reg);
	   return((reg.x.bx==1));
	  }

  int  Right()
	  {
	   reg.x.ax=0x03;
	   int86(0x33,&reg,&reg);
	   return((reg.x.bx==2));
	  }
   int MouseIn(int x1,int x2,int y1,int y2)
  {
       reg.x.ax=0x03;
	int86(0x33,&reg,&reg);
	reg.x.bx=2;

    //while((reg.x.bx!=1));
    return((X()>=x1)&(X()<=x2)&(Y()<=y2)&(Y()>=y1));
 }
int etat(void)
{
	reg.x.ax=0x03;
	int86(0x33,&reg,&reg);
	return(reg.x.bx);
}


